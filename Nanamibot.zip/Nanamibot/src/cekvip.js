const cekvip = () => { 
	return `           
──────────────────
*Nama bot* :  NANAMI BOT
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ACTIVE*
────────────────── 
*Status Bot:* *Online*
────────────────── `
}
exports.cekvip = cekvip